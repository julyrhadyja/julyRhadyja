<!DOCTYPE html>
<html>
<head>
	<title> AS BRANQUELAS </title>
</head>
<body>
	<h1> Informações sobre o filme escolhido  </h1>
  <img php/asbranq.jpg> 
	<p/>
	<h3> 14 anos 109 min. Comédia EUA 2004 Keenen Ivory Wayans.
TÍTULO ORIGINAL: (White Chicks)

IDIOMA: Inglês LEGENDA: Português
		<p/>
ELENCO: Shawn Wayans, Marlon Wayans, Maitland Ward e Lochlyn Munro </h3>
	<p/>
	<h2> Sinopse </h2>
	<h3> Dois irmãos agentes do FBI, Marcus e Kevin, acidentalmente evitam que bandidos sejam presos em uma apreensão de drogas. Como castigos, eles são obrigados a escoltar um par de socialites para o Hampton.
		Porém quando as meninas descobrem o plano do FBI, elas se recusam a ir. Sem opções, Marcus e Kevin de cidem posar como irmãs, transformando - se em um par de loiras. </h3>

</body>
</html>
