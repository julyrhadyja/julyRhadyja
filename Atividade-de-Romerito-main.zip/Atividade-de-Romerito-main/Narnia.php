<!DOCTYPE html>
<html>
<head>
	<title>NARNIA</title>
	<link rel="stylesheet" type="text/css" href="CSS.css">
</head>
<body>
	<div id="rig">
		<h1> Informações sobre o filme escolhido  </h1>
		<p/>
		<h3>9 de dezembro de 2005 No cinema</h3>
		<h3>2h 20min</h3>
		<h3>Gênero: Fantasia, Aventura,Família</h3>
		<h3>Direção: Andrew Adamson</h3>
		<h3>Elenco: Georgie Henley, Skandar Keynes, Anna Popplewell</h3>
		<h3>Título original The Chronicles of Narnia : The Lion, the Witch and the Wardrobe</h3>
		<h2>Sinopse: </h2>
		<h3>Durante os bombardeios da Segunda Guerra Mundial de Londres, quatro irmãos ingleses são enviados para uma casa de campo onde eles estarão seguros. Um dia, Lucy encontra um guarda-roupa que a transporta para um mundo mágico chamado Nárnia. Depois de voltar, ela logo volta a Nárnia com seus irmãos, Peter e Edmund, e sua irmã, Susan. Lá eles se juntam ao leão mágico, Aslan, na luta contra a Feiticeira Branca.</h3>	
	</div>
	<div class="left">
			<img src="narnia.jpg">
	</div>
</body>  	
</html>
