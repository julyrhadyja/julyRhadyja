<!DOCTYPE html>
<html>
<head>
	<title> ROMEFLIX </title>
</head>
<body>
	<h1> ROMEFLIX  </h1>
	<h2> Bem - vindo a sua página de filmes </h2>
	//adicionar as imagens 
	//adicionar link da pag de info do filme determinado
	<img> ____ </img>
	<a link=""> Título do Filme </a>
	<img> ____ </img>
	<a link=""> Título do Filme </a>
	<img> ____ </img>
	<a link=""> Título do Filme </a>

</body>
</html>
