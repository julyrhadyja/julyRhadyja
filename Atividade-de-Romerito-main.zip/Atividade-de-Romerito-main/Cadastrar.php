<!DOCTYPE html>
<html>
<head>
	<title>Tela de Login</title>
	<link rel="stylesheet" type="text/css" href="CSS.css">
</head>
<body id="cad">
	<div id="cd">
		<h1 class="login1"> Bem - vindo a sua tela de login </h1>
		<h2 class="login2"> Insira as suas informações </h2>
		<input type="text" name="login" placeholder="Nome de Usuário">
		<p/>
		<input type="password" name="senha" placeholder="Senha">
		<p/>
		<button>Enviar</button>
	</div>
</body>
</html>
