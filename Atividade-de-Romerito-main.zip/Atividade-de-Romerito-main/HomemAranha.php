<!DOCTYPE html>
<html>
<head>
	<title> Homem Aranha </title>
</head>
<body>
	<h1> Informações sobre o filme escolhido  </h1>
  //nicolly, bote a imagem do primeiro filme do Tobey
  <img > 
	<p/>
	<h3> 12 anos 120 min. Ficção Científica / Ação e Aventura EUA 2002  Sam Raimi.
TÍTULO ORIGINAL: (Spider Man)
IDIOMA: Inglês / Português LEGENDA: Inglês / Português
		<p/>
ELENCO: Tobey Maguire, Kirsten Dunst, Willem Dafoe, James Franco </h3>
	<p/>
	<h2> Sinopse </h2>
	<h3> Depois de ser picado por uma aranha geneticamente modificada em uma demonstração científica, o jovem nerd Peter Parker ganha superpoderes. Inicialmente, ele pretende usá-los para para ganhar dinheiro, adotando o nome de Homem-Aranha e se apresentando em lutas de exibição.
    Porém, ao presenciar o assassinando de seu tio Ben e sentir-se culpado, Peter decide não mais usar seus poderes para proveito próprio e sim para enfrentar o mal, tendo como seu primeiro grande desafio o psicótico Duende Verde. </h3>
</body>
</html>
