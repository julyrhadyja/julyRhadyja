<?php

echo "funcionando";

?>